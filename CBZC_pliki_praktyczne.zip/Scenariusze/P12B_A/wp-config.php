<?php
// Dane wyłącznie fikcyjne
define('DB_NAME','forum_lab');
define('DB_USER','kurs');
