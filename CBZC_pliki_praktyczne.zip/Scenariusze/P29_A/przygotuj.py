# CBZC: autorskie cwiczenie TCP i dekodowania Base64 -> HEX -> UTF-8.
# To nie rekonstrukcja skryptu egzaminacyjnego. Nie tworzy VeraCrypt.
from pathlib import Path
import base64, hashlib
TCP_HANDSHAKE = ["?", "?", "?"]
DECODED_TEXT = ""
PHOTO_MODEL = ""
PASSWORD_FROM_HEX = ""
ENCODED_TEXT = "NDggNDEgNGUgNDQgNTMgNDggNDEgNGIgNDUgMmQgNDEgMmQgNGYgNGI="
if TCP_HANDSHAKE != ["SYN", "SYN/ACK", "ACK"]:
    raise SystemExit("BLAD: popraw kolejnosc handshake TCP.")
expected = bytes.fromhex(base64.b64decode(ENCODED_TEXT).decode("ascii")).decode("utf-8")
if DECODED_TEXT != expected:
    raise SystemExit("BLAD: odkoduj tekst i wklej wynik bez konca wiersza.")
if PHOTO_MODEL != "CBZC-A":
    raise SystemExit("BLAD: odczytaj Model przy pomocy ExifTool.")
if hashlib.sha256(PASSWORD_FROM_HEX.encode()).hexdigest() != "3d06027f7f6c1f4e805f722ff7024f0e079f94da7aa1587ac2a821fffad51b16":
    raise SystemExit("BLAD: odczytaj HASLO_VC na koncu zdjecia w GHex/strings.")
result = "ETAPY: SYN -> SYN/ACK -> ACK\nTOKEN: " + DECODED_TEXT + "\nMODEL: " + PHOTO_MODEL + "\nHASLO_KONTENERA: " + PASSWORD_FROM_HEX + "\n"
p = Path("wynik_skryptu.txt")
if p.exists():
    raise SystemExit("Plik wynik_skryptu.txt juz istnieje; zachowaj go lub wybierz nowy katalog cwiczenia.")
p.write_text(result, encoding="utf-8")
print("OK: zapisano wynik_skryptu.txt. Utworz nowy PLIK kontenera w kreatorze VeraCrypt.")
