<?php
// Przyklad konfiguracji WordPress; fikcyjny podzbior do analizy.
define('DB_NAME', 'forum_lab_b');
define('DB_USER', 'root');
define('DB_HOST', 'localhost');
$table_prefix = 'wp_';
