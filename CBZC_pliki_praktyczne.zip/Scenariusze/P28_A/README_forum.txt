Podzbior bazy do nauki, nie dzialajaca instalacja WordPress.
Import SQL do nowej pustej bazy w phpMyAdmin (MySQL/MariaDB). Nie importuj do istniejacego forum.
Pole cbzc_lab_created_utc jest AUTORSKIM polem cwiczenia, nie standardowym polem WordPress.
Konto 1 zostalo przeniesione ze starszego systemu. Data rejestracji nie dowodzi daty zalozenia forum.
DB_USER w wp-config.php to konto bazy, nie rola administratora forum.
