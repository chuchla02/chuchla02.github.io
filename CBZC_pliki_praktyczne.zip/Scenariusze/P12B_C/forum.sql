CREATE TABLE users (id INTEGER, login VARCHAR(80), role VARCHAR(30), email VARCHAR(150));
CREATE TABLE posts (id INTEGER, title VARCHAR(100), status VARCHAR(30), category VARCHAR(30), user_id INTEGER);
INSERT INTO users VALUES (1,'pierwszy','user','pierwszy@example.net'),(2,'moderator','admin','moderator@example.net'),(3,'jan','user','jan@example.net'),(4,'ewa','user','ewa@example.net');
INSERT INTO posts VALUES (1,'Monitor','published','sprzet',3),(2,'Rower','pending','sport',4),(3,'Klawiatura','published','sprzet',2);
