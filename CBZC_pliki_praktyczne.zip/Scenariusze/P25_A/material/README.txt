Material do liczenia; obejmij nazwy z kropka.
